__title__ = 'lexrankr'
__version__ = '0.1'
__author__ = 'Jamie Seol'
__license__ = 'MIT'
__copyright__ = 'Copyright 2016 Jamie Seol'

from .lexrankr import *
